export default function Date() {
  return (
    <div>
      <form action="/api/test" method="GET">
        <button type="submit">몇시인지알려주쇼</button>
      </form>
    </div>
  );
}
