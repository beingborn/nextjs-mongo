let age = 20;
export default age;
