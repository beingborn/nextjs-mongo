export default function Mypage() {
  return (
    <div>
      <h4>00님 안녕하세요</h4>
    </div>
  );
}
