export default function ReWrite() {
  return (
    <div>
      <h2>글을 써보세요</h2>
      <div className="article">
        <h4>3번째 기사</h4>
      </div>
      <div className="article">
        <h4>4번째 기사</h4>
      </div>
    </div>
  );
}
