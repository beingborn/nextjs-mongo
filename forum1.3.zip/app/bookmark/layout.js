export default function Layout({ children }) {
  return (
    <div>
      <p>첫 글을 북마크 해보세요!</p>
      {children}
    </div>
  );
}
